import requests

# Placeholder script - later will handle Excel file upload to server
print("Manual sync script will be configured after server deployment.")
